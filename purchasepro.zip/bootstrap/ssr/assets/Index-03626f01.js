import { defineComponent, resolveComponent, unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { Head, Link } from "@inertiajs/vue3";
import { G as GuestLayout } from "./GuestLayout-98337e8a.js";
import { u as useCart } from "./cart-ae7434ff.js";
import "axios";
import "pinia";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: ["product"],
  setup(__props) {
    const cart = useCart();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_container = resolveComponent("v-container");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_carousel = resolveComponent("v-carousel");
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_subtitle = resolveComponent("v-card-subtitle");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), {
        title: __props.product.name
      }, null, _parent));
      _push(ssrRenderComponent(GuestLayout, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_container, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("product.archive")
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_v_btn, {
                          icon: "mdi-arrow-left",
                          variant: "plain"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_v_btn, {
                            icon: "mdi-arrow-left",
                            variant: "plain"
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_v_row, null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_v_col, { cols: "5" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_v_carousel, null, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<!--[-->`);
                                    ssrRenderList(__props.product.product_image, (image, key) => {
                                      _push6(ssrRenderComponent(_component_v_carousel_item, {
                                        key,
                                        src: image.url,
                                        cover: ""
                                      }, null, _parent6, _scopeId5));
                                    });
                                    _push6(`<!--]-->`);
                                  } else {
                                    return [
                                      (openBlock(true), createBlock(Fragment, null, renderList(__props.product.product_image, (image, key) => {
                                        return openBlock(), createBlock(_component_v_carousel_item, {
                                          key,
                                          src: image.url,
                                          cover: ""
                                        }, null, 8, ["src"]);
                                      }), 128))
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_v_carousel, null, {
                                  default: withCtx(() => [
                                    (openBlock(true), createBlock(Fragment, null, renderList(__props.product.product_image, (image, key) => {
                                      return openBlock(), createBlock(_component_v_carousel_item, {
                                        key,
                                        src: image.url,
                                        cover: ""
                                      }, null, 8, ["src"]);
                                    }), 128))
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_v_col, { cols: "7" }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_v_card, { class: "fill-height" }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_v_card_title, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<h1${_scopeId6}>${ssrInterpolate(__props.product.name)}</h1>`);
                                        } else {
                                          return [
                                            createVNode("h1", null, toDisplayString(__props.product.name), 1)
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_v_card_subtitle, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(` $${ssrInterpolate(__props.product.price)}`);
                                        } else {
                                          return [
                                            createTextVNode(" $" + toDisplayString(__props.product.price), 1)
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_v_card_text, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<h2 class="mb-3"${_scopeId6}>Details:</h2><p${_scopeId6}>${ssrInterpolate(__props.product.details)}</p>`);
                                        } else {
                                          return [
                                            createVNode("h2", { class: "mb-3" }, "Details:"),
                                            createVNode("p", null, toDisplayString(__props.product.details), 1)
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_v_card_actions, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(ssrRenderComponent(_component_v_btn, {
                                            color: "warning",
                                            variant: "text",
                                            "append-icon": "mdi-cart-plus",
                                            onClick: ($event) => unref(cart).addToCart(__props.product)
                                          }, {
                                            default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                              if (_push8) {
                                                _push8(` Add to cart `);
                                              } else {
                                                return [
                                                  createTextVNode(" Add to cart ")
                                                ];
                                              }
                                            }),
                                            _: 1
                                          }, _parent7, _scopeId6));
                                        } else {
                                          return [
                                            createVNode(_component_v_btn, {
                                              color: "warning",
                                              variant: "text",
                                              "append-icon": "mdi-cart-plus",
                                              onClick: ($event) => unref(cart).addToCart(__props.product)
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(" Add to cart ")
                                              ]),
                                              _: 1
                                            }, 8, ["onClick"])
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_v_card_title, null, {
                                        default: withCtx(() => [
                                          createVNode("h1", null, toDisplayString(__props.product.name), 1)
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_v_card_subtitle, null, {
                                        default: withCtx(() => [
                                          createTextVNode(" $" + toDisplayString(__props.product.price), 1)
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_v_card_text, null, {
                                        default: withCtx(() => [
                                          createVNode("h2", { class: "mb-3" }, "Details:"),
                                          createVNode("p", null, toDisplayString(__props.product.details), 1)
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_v_card_actions, null, {
                                        default: withCtx(() => [
                                          createVNode(_component_v_btn, {
                                            color: "warning",
                                            variant: "text",
                                            "append-icon": "mdi-cart-plus",
                                            onClick: ($event) => unref(cart).addToCart(__props.product)
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(" Add to cart ")
                                            ]),
                                            _: 1
                                          }, 8, ["onClick"])
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_v_card, { class: "fill-height" }, {
                                  default: withCtx(() => [
                                    createVNode(_component_v_card_title, null, {
                                      default: withCtx(() => [
                                        createVNode("h1", null, toDisplayString(__props.product.name), 1)
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_v_card_subtitle, null, {
                                      default: withCtx(() => [
                                        createTextVNode(" $" + toDisplayString(__props.product.price), 1)
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_v_card_text, null, {
                                      default: withCtx(() => [
                                        createVNode("h2", { class: "mb-3" }, "Details:"),
                                        createVNode("p", null, toDisplayString(__props.product.details), 1)
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_v_card_actions, null, {
                                      default: withCtx(() => [
                                        createVNode(_component_v_btn, {
                                          color: "warning",
                                          variant: "text",
                                          "append-icon": "mdi-cart-plus",
                                          onClick: ($event) => unref(cart).addToCart(__props.product)
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Add to cart ")
                                          ]),
                                          _: 1
                                        }, 8, ["onClick"])
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_v_col, { cols: "5" }, {
                            default: withCtx(() => [
                              createVNode(_component_v_carousel, null, {
                                default: withCtx(() => [
                                  (openBlock(true), createBlock(Fragment, null, renderList(__props.product.product_image, (image, key) => {
                                    return openBlock(), createBlock(_component_v_carousel_item, {
                                      key,
                                      src: image.url,
                                      cover: ""
                                    }, null, 8, ["src"]);
                                  }), 128))
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_v_col, { cols: "7" }, {
                            default: withCtx(() => [
                              createVNode(_component_v_card, { class: "fill-height" }, {
                                default: withCtx(() => [
                                  createVNode(_component_v_card_title, null, {
                                    default: withCtx(() => [
                                      createVNode("h1", null, toDisplayString(__props.product.name), 1)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_subtitle, null, {
                                    default: withCtx(() => [
                                      createTextVNode(" $" + toDisplayString(__props.product.price), 1)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_text, null, {
                                    default: withCtx(() => [
                                      createVNode("h2", { class: "mb-3" }, "Details:"),
                                      createVNode("p", null, toDisplayString(__props.product.details), 1)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_actions, null, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_btn, {
                                        color: "warning",
                                        variant: "text",
                                        "append-icon": "mdi-cart-plus",
                                        onClick: ($event) => unref(cart).addToCart(__props.product)
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Add to cart ")
                                        ]),
                                        _: 1
                                      }, 8, ["onClick"])
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_v_row, null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_v_card, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_v_card_title, null, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(` Description `);
                                  } else {
                                    return [
                                      createTextVNode(" Description ")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                              _push5(ssrRenderComponent(_component_v_card_text, null, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`<p${_scopeId5}>${ssrInterpolate(__props.product.description)}</p>`);
                                  } else {
                                    return [
                                      createVNode("p", null, toDisplayString(__props.product.description), 1)
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_v_card_title, null, {
                                  default: withCtx(() => [
                                    createTextVNode(" Description ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_v_card_text, null, {
                                  default: withCtx(() => [
                                    createVNode("p", null, toDisplayString(__props.product.description), 1)
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_v_card, null, {
                            default: withCtx(() => [
                              createVNode(_component_v_card_title, null, {
                                default: withCtx(() => [
                                  createTextVNode(" Description ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_card_text, null, {
                                default: withCtx(() => [
                                  createVNode("p", null, toDisplayString(__props.product.description), 1)
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Link), {
                      href: _ctx.route("product.archive")
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, {
                          icon: "mdi-arrow-left",
                          variant: "plain"
                        })
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_component_v_row, null, {
                      default: withCtx(() => [
                        createVNode(_component_v_col, { cols: "5" }, {
                          default: withCtx(() => [
                            createVNode(_component_v_carousel, null, {
                              default: withCtx(() => [
                                (openBlock(true), createBlock(Fragment, null, renderList(__props.product.product_image, (image, key) => {
                                  return openBlock(), createBlock(_component_v_carousel_item, {
                                    key,
                                    src: image.url,
                                    cover: ""
                                  }, null, 8, ["src"]);
                                }), 128))
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_col, { cols: "7" }, {
                          default: withCtx(() => [
                            createVNode(_component_v_card, { class: "fill-height" }, {
                              default: withCtx(() => [
                                createVNode(_component_v_card_title, null, {
                                  default: withCtx(() => [
                                    createVNode("h1", null, toDisplayString(__props.product.name), 1)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_v_card_subtitle, null, {
                                  default: withCtx(() => [
                                    createTextVNode(" $" + toDisplayString(__props.product.price), 1)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_v_card_text, null, {
                                  default: withCtx(() => [
                                    createVNode("h2", { class: "mb-3" }, "Details:"),
                                    createVNode("p", null, toDisplayString(__props.product.details), 1)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_v_card_actions, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_v_btn, {
                                      color: "warning",
                                      variant: "text",
                                      "append-icon": "mdi-cart-plus",
                                      onClick: ($event) => unref(cart).addToCart(__props.product)
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Add to cart ")
                                      ]),
                                      _: 1
                                    }, 8, ["onClick"])
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }),
                    createVNode(_component_v_row, null, {
                      default: withCtx(() => [
                        createVNode(_component_v_card, null, {
                          default: withCtx(() => [
                            createVNode(_component_v_card_title, null, {
                              default: withCtx(() => [
                                createTextVNode(" Description ")
                              ]),
                              _: 1
                            }),
                            createVNode(_component_v_card_text, null, {
                              default: withCtx(() => [
                                createVNode("p", null, toDisplayString(__props.product.description), 1)
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_container, null, {
                default: withCtx(() => [
                  createVNode(unref(Link), {
                    href: _ctx.route("product.archive")
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, {
                        icon: "mdi-arrow-left",
                        variant: "plain"
                      })
                    ]),
                    _: 1
                  }, 8, ["href"]),
                  createVNode(_component_v_row, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, { cols: "5" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_carousel, null, {
                            default: withCtx(() => [
                              (openBlock(true), createBlock(Fragment, null, renderList(__props.product.product_image, (image, key) => {
                                return openBlock(), createBlock(_component_v_carousel_item, {
                                  key,
                                  src: image.url,
                                  cover: ""
                                }, null, 8, ["src"]);
                              }), 128))
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, { cols: "7" }, {
                        default: withCtx(() => [
                          createVNode(_component_v_card, { class: "fill-height" }, {
                            default: withCtx(() => [
                              createVNode(_component_v_card_title, null, {
                                default: withCtx(() => [
                                  createVNode("h1", null, toDisplayString(__props.product.name), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_card_subtitle, null, {
                                default: withCtx(() => [
                                  createTextVNode(" $" + toDisplayString(__props.product.price), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_card_text, null, {
                                default: withCtx(() => [
                                  createVNode("h2", { class: "mb-3" }, "Details:"),
                                  createVNode("p", null, toDisplayString(__props.product.details), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_card_actions, null, {
                                default: withCtx(() => [
                                  createVNode(_component_v_btn, {
                                    color: "warning",
                                    variant: "text",
                                    "append-icon": "mdi-cart-plus",
                                    onClick: ($event) => unref(cart).addToCart(__props.product)
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Add to cart ")
                                    ]),
                                    _: 1
                                  }, 8, ["onClick"])
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }),
                  createVNode(_component_v_row, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_card, null, {
                        default: withCtx(() => [
                          createVNode(_component_v_card_title, null, {
                            default: withCtx(() => [
                              createTextVNode(" Description ")
                            ]),
                            _: 1
                          }),
                          createVNode(_component_v_card_text, null, {
                            default: withCtx(() => [
                              createVNode("p", null, toDisplayString(__props.product.description), 1)
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Product/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
