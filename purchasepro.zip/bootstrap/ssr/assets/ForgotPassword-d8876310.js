import { defineComponent, reactive, computed, resolveComponent, unref, withCtx, createTextVNode, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { useVuelidate } from "@vuelidate/core";
import { required, email } from "@vuelidate/validators";
import { useForm, Head } from "@inertiajs/vue3";
import { L as Layout, C as CustomInput, g as generateErrors } from "./errorGenerator-448112f0.js";
import "@vue/reactivity";
import "@vue/runtime-core";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ForgotPassword",
  __ssrInlineRender: true,
  props: {
    status: {}
  },
  setup(__props) {
    const form = useForm({
      email: ""
    });
    const $externalResults = reactive({});
    const rules = computed(() => ({
      email: {
        required,
        email
      }
    }));
    const v$ = useVuelidate(rules, form, { $externalResults });
    const submit = async () => {
      await v$.value.$touch();
      if (v$.value.$invalid) {
        return await false;
      }
      form.post(route("password.email"), {
        onError: async (err) => {
          await Object.keys(err).forEach((item) => {
            $externalResults[item] = err[item];
          });
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_toolbar_title = resolveComponent("v-toolbar-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_form = resolveComponent("v-form");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_btn = resolveComponent("v-btn");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Forgot Password" }, null, _parent));
      _push(ssrRenderComponent(Layout, {
        isLoading: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_card_title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_v_toolbar_title, null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Forgot Password`);
                      } else {
                        return [
                          createTextVNode("Forgot Password")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_v_toolbar_title, null, {
                      default: withCtx(() => [
                        createTextVNode("Forgot Password")
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_card_text, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="mb-4 text-sm text-gray-600"${_scopeId2}> Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one. </div>`);
                  if (_ctx.status) {
                    _push3(`<div class="mb-4 font-medium text-sm text-green-600"${_scopeId2}>${ssrInterpolate(_ctx.status)}</div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(ssrRenderComponent(_component_v_form, { onSubmit: submit }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).email,
                          "onUpdate:modelValue": ($event) => unref(form).email = $event,
                          errorMessages: unref(generateErrors)(unref(v$).email),
                          label: "Email",
                          required: "",
                          type: "email",
                          onInput: ($event) => unref(v$).email.$touch(),
                          onBlur: ($event) => unref(v$).email.$touch()
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(CustomInput, {
                            modelValue: unref(form).email,
                            "onUpdate:modelValue": ($event) => unref(form).email = $event,
                            errorMessages: unref(generateErrors)(unref(v$).email),
                            label: "Email",
                            required: "",
                            type: "email",
                            onInput: ($event) => unref(v$).email.$touch(),
                            onBlur: ($event) => unref(v$).email.$touch()
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("div", { class: "mb-4 text-sm text-gray-600" }, " Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one. "),
                    _ctx.status ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "mb-4 font-medium text-sm text-green-600"
                    }, toDisplayString(_ctx.status), 1)) : createCommentVNode("", true),
                    createVNode(_component_v_form, {
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(CustomInput, {
                          modelValue: unref(form).email,
                          "onUpdate:modelValue": ($event) => unref(form).email = $event,
                          errorMessages: unref(generateErrors)(unref(v$).email),
                          label: "Email",
                          required: "",
                          type: "email",
                          onInput: ($event) => unref(v$).email.$touch(),
                          onBlur: ($event) => unref(v$).email.$touch()
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"])
                      ]),
                      _: 1
                    }, 8, ["onSubmit"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_card_actions, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_v_btn, {
                    rounded: "pill",
                    color: "#5D5FEF",
                    type: "submit",
                    width: "100%",
                    onClick: submit,
                    variant: "elevated",
                    loading: unref(form).processing
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Email Password Reset Link`);
                      } else {
                        return [
                          createTextVNode("Email Password Reset Link")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_v_btn, {
                      rounded: "pill",
                      color: "#5D5FEF",
                      type: "submit",
                      width: "100%",
                      onClick: submit,
                      variant: "elevated",
                      loading: unref(form).processing
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Email Password Reset Link")
                      ]),
                      _: 1
                    }, 8, ["loading"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_card_title, null, {
                default: withCtx(() => [
                  createVNode(_component_v_toolbar_title, null, {
                    default: withCtx(() => [
                      createTextVNode("Forgot Password")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createVNode("div", { class: "mb-4 text-sm text-gray-600" }, " Forgot your password? No problem. Just let us know your email address and we will email you a password reset link that will allow you to choose a new one. "),
                  _ctx.status ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "mb-4 font-medium text-sm text-green-600"
                  }, toDisplayString(_ctx.status), 1)) : createCommentVNode("", true),
                  createVNode(_component_v_form, {
                    onSubmit: withModifiers(submit, ["prevent"])
                  }, {
                    default: withCtx(() => [
                      createVNode(CustomInput, {
                        modelValue: unref(form).email,
                        "onUpdate:modelValue": ($event) => unref(form).email = $event,
                        errorMessages: unref(generateErrors)(unref(v$).email),
                        label: "Email",
                        required: "",
                        type: "email",
                        onInput: ($event) => unref(v$).email.$touch(),
                        onBlur: ($event) => unref(v$).email.$touch()
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"])
                    ]),
                    _: 1
                  }, 8, ["onSubmit"])
                ]),
                _: 1
              }),
              createVNode(_component_v_card_actions, null, {
                default: withCtx(() => [
                  createVNode(_component_v_btn, {
                    rounded: "pill",
                    color: "#5D5FEF",
                    type: "submit",
                    width: "100%",
                    onClick: submit,
                    variant: "elevated",
                    loading: unref(form).processing
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Email Password Reset Link")
                    ]),
                    _: 1
                  }, 8, ["loading"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/ForgotPassword.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
