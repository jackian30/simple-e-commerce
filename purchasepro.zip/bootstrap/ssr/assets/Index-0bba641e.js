import { defineComponent, ref, watch, resolveComponent, mergeProps, withCtx, createVNode, useSSRContext, openBlock, createBlock, Fragment, renderList, createTextVNode, toDisplayString, unref, withKeys, withModifiers } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { Link, Head, router } from "@inertiajs/vue3";
import { G as GuestLayout } from "./GuestLayout-98337e8a.js";
import { u as useCart } from "./cart-ae7434ff.js";
import "axios";
import "pinia";
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "ProductPagination",
  __ssrInlineRender: true,
  props: ["link"],
  emits: ["changePage"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const page = ref(props.link.current_page);
    watch(() => page.value, (newVal) => {
      emit("changePage", newVal);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_row = resolveComponent("v-row");
      const _component_v_pagination = resolveComponent("v-pagination");
      _push(ssrRenderComponent(_component_v_row, mergeProps({
        align: "center",
        justify: "center",
        "no-gutters": "",
        class: "p-5"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_pagination, {
              modelValue: page.value,
              "onUpdate:modelValue": ($event) => page.value = $event,
              length: __props.link.last_page,
              "total-visible": 5,
              rounded: "circle"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_pagination, {
                modelValue: page.value,
                "onUpdate:modelValue": ($event) => page.value = $event,
                length: __props.link.last_page,
                "total-visible": 5,
                rounded: "circle"
              }, null, 8, ["modelValue", "onUpdate:modelValue", "length"])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Common/ProductPagination.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ProductCard",
  __ssrInlineRender: true,
  props: ["product"],
  setup(__props) {
    const cart = useCart();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_card = resolveComponent("v-card");
      const _component_v_carousel = resolveComponent("v-carousel");
      const _component_v_carousel_item = resolveComponent("v-carousel-item");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_subtitle = resolveComponent("v-card-subtitle");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_spacer = resolveComponent("v-spacer");
      _push(ssrRenderComponent(_component_v_card, _attrs, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_carousel, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(__props.product.product_image, (image, key) => {
                    _push3(ssrRenderComponent(_component_v_carousel_item, {
                      key,
                      src: image.url,
                      cover: ""
                    }, null, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.product.product_image, (image, key) => {
                      return openBlock(), createBlock(_component_v_carousel_item, {
                        key,
                        src: image.url,
                        cover: ""
                      }, null, 8, ["src"]);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_card_title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`${ssrInterpolate(__props.product.name)}`);
                } else {
                  return [
                    createTextVNode(toDisplayString(__props.product.name), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_card_subtitle, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` $${ssrInterpolate(__props.product.price)}`);
                } else {
                  return [
                    createTextVNode(" $" + toDisplayString(__props.product.price), 1)
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_card_actions, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("product.index", __props.product.slug)
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_v_btn, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(` View Details `);
                            } else {
                              return [
                                createTextVNode(" View Details ")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_v_btn, null, {
                            default: withCtx(() => [
                              createTextVNode(" View Details ")
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_v_spacer, null, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("checkout.single.show", __props.product.id),
                    class: "mr-2"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_v_btn, {
                          color: "primary",
                          variant: "elevated",
                          "append-icon": "mdi-cart-check",
                          onClick: ($event) => unref(cart).addToCart(__props.product)
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(` Checkout `);
                            } else {
                              return [
                                createTextVNode(" Checkout ")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_v_btn, {
                            color: "primary",
                            variant: "elevated",
                            "append-icon": "mdi-cart-check",
                            onClick: ($event) => unref(cart).addToCart(__props.product)
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Checkout ")
                            ]),
                            _: 1
                          }, 8, ["onClick"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_v_btn, {
                    color: "warning",
                    variant: "elevated",
                    "append-icon": "mdi-cart-plus",
                    onClick: ($event) => unref(cart).addToCart(__props.product)
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(` Add to cart `);
                      } else {
                        return [
                          createTextVNode(" Add to cart ")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Link), {
                      href: _ctx.route("product.index", __props.product.slug)
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, null, {
                          default: withCtx(() => [
                            createTextVNode(" View Details ")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_component_v_spacer),
                    createVNode(unref(Link), {
                      href: _ctx.route("checkout.single.show", __props.product.id),
                      class: "mr-2"
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, {
                          color: "primary",
                          variant: "elevated",
                          "append-icon": "mdi-cart-check",
                          onClick: ($event) => unref(cart).addToCart(__props.product)
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Checkout ")
                          ]),
                          _: 1
                        }, 8, ["onClick"])
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_component_v_btn, {
                      color: "warning",
                      variant: "elevated",
                      "append-icon": "mdi-cart-plus",
                      onClick: ($event) => unref(cart).addToCart(__props.product)
                    }, {
                      default: withCtx(() => [
                        createTextVNode(" Add to cart ")
                      ]),
                      _: 1
                    }, 8, ["onClick"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_carousel, null, {
                default: withCtx(() => [
                  (openBlock(true), createBlock(Fragment, null, renderList(__props.product.product_image, (image, key) => {
                    return openBlock(), createBlock(_component_v_carousel_item, {
                      key,
                      src: image.url,
                      cover: ""
                    }, null, 8, ["src"]);
                  }), 128))
                ]),
                _: 1
              }),
              createVNode(_component_v_card_title, null, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(__props.product.name), 1)
                ]),
                _: 1
              }),
              createVNode(_component_v_card_subtitle, null, {
                default: withCtx(() => [
                  createTextVNode(" $" + toDisplayString(__props.product.price), 1)
                ]),
                _: 1
              }),
              createVNode(_component_v_card_actions, null, {
                default: withCtx(() => [
                  createVNode(unref(Link), {
                    href: _ctx.route("product.index", __props.product.slug)
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, null, {
                        default: withCtx(() => [
                          createTextVNode(" View Details ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["href"]),
                  createVNode(_component_v_spacer),
                  createVNode(unref(Link), {
                    href: _ctx.route("checkout.single.show", __props.product.id),
                    class: "mr-2"
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, {
                        color: "primary",
                        variant: "elevated",
                        "append-icon": "mdi-cart-check",
                        onClick: ($event) => unref(cart).addToCart(__props.product)
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Checkout ")
                        ]),
                        _: 1
                      }, 8, ["onClick"])
                    ]),
                    _: 1
                  }, 8, ["href"]),
                  createVNode(_component_v_btn, {
                    color: "warning",
                    variant: "elevated",
                    "append-icon": "mdi-cart-plus",
                    onClick: ($event) => unref(cart).addToCart(__props.product)
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Add to cart ")
                    ]),
                    _: 1
                  }, 8, ["onClick"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Common/ProductCard.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  props: ["products", "search"],
  setup(__props) {
    const props = __props;
    const search = ref(props.search);
    useCart();
    function navigateTo(page) {
      let link = `${props.products.path}?page=${page}`;
      if (search.value) {
        link = `${link}&search=${search.value}`;
      }
      router.visit(link);
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_container = resolveComponent("v-container");
      const _component_v_form = resolveComponent("v-form");
      const _component_v_text_field = resolveComponent("v-text-field");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Home" }, null, _parent));
      _push(ssrRenderComponent(GuestLayout, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_container, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_v_form, { onSubmit: () => {
                  } }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_v_text_field, {
                          variant: "outlined",
                          label: "Search",
                          modelValue: search.value,
                          "onUpdate:modelValue": ($event) => search.value = $event,
                          "append-icon": "mdi-magnify",
                          "onClick:append": ($event) => navigateTo(1),
                          "onClick:clear": ($event) => navigateTo(1),
                          onKeydown: ($event) => navigateTo(1),
                          clearable: ""
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_v_text_field, {
                            variant: "outlined",
                            label: "Search",
                            modelValue: search.value,
                            "onUpdate:modelValue": ($event) => search.value = $event,
                            "append-icon": "mdi-magnify",
                            "onClick:append": ($event) => navigateTo(1),
                            "onClick:clear": ($event) => navigateTo(1),
                            onKeydown: withKeys(($event) => navigateTo(1), ["enter"]),
                            clearable: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "onClick:append", "onClick:clear", "onKeydown"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_v_container, { class: "grid md:grid-cols-3 grid-cols-1 gap-10" }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`<!--[-->`);
                        ssrRenderList(__props.products.data, (product) => {
                          _push4(ssrRenderComponent(_sfc_main$1, {
                            key: product.id,
                            product
                          }, null, _parent4, _scopeId3));
                        });
                        _push4(`<!--]-->`);
                      } else {
                        return [
                          (openBlock(true), createBlock(Fragment, null, renderList(__props.products.data, (product) => {
                            return openBlock(), createBlock(_sfc_main$1, {
                              key: product.id,
                              product
                            }, null, 8, ["product"]);
                          }), 128))
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_sfc_main$2, {
                    link: __props.products,
                    onChangePage: navigateTo
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_v_form, {
                      onSubmit: withModifiers(() => {
                      }, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_text_field, {
                          variant: "outlined",
                          label: "Search",
                          modelValue: search.value,
                          "onUpdate:modelValue": ($event) => search.value = $event,
                          "append-icon": "mdi-magnify",
                          "onClick:append": ($event) => navigateTo(1),
                          "onClick:clear": ($event) => navigateTo(1),
                          onKeydown: withKeys(($event) => navigateTo(1), ["enter"]),
                          clearable: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "onClick:append", "onClick:clear", "onKeydown"])
                      ]),
                      _: 1
                    }, 8, ["onSubmit"]),
                    createVNode(_component_v_container, { class: "grid md:grid-cols-3 grid-cols-1 gap-10" }, {
                      default: withCtx(() => [
                        (openBlock(true), createBlock(Fragment, null, renderList(__props.products.data, (product) => {
                          return openBlock(), createBlock(_sfc_main$1, {
                            key: product.id,
                            product
                          }, null, 8, ["product"]);
                        }), 128))
                      ]),
                      _: 1
                    }),
                    createVNode(_sfc_main$2, {
                      link: __props.products,
                      onChangePage: navigateTo
                    }, null, 8, ["link"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_container, null, {
                default: withCtx(() => [
                  createVNode(_component_v_form, {
                    onSubmit: withModifiers(() => {
                    }, ["prevent"])
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_text_field, {
                        variant: "outlined",
                        label: "Search",
                        modelValue: search.value,
                        "onUpdate:modelValue": ($event) => search.value = $event,
                        "append-icon": "mdi-magnify",
                        "onClick:append": ($event) => navigateTo(1),
                        "onClick:clear": ($event) => navigateTo(1),
                        onKeydown: withKeys(($event) => navigateTo(1), ["enter"]),
                        clearable: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "onClick:append", "onClick:clear", "onKeydown"])
                    ]),
                    _: 1
                  }, 8, ["onSubmit"]),
                  createVNode(_component_v_container, { class: "grid md:grid-cols-3 grid-cols-1 gap-10" }, {
                    default: withCtx(() => [
                      (openBlock(true), createBlock(Fragment, null, renderList(__props.products.data, (product) => {
                        return openBlock(), createBlock(_sfc_main$1, {
                          key: product.id,
                          product
                        }, null, 8, ["product"]);
                      }), 128))
                    ]),
                    _: 1
                  }),
                  createVNode(_sfc_main$2, {
                    link: __props.products,
                    onChangePage: navigateTo
                  }, null, 8, ["link"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
