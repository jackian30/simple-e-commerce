import { defineComponent, computed, resolveComponent, unref, withCtx, createVNode, createTextVNode, toDisplayString, openBlock, createBlock, Fragment, renderList, useSSRContext } from "vue";
import { ssrRenderComponent, ssrRenderList, ssrInterpolate } from "vue/server-renderer";
import { Head, Link, router } from "@inertiajs/vue3";
import { C as Counter } from "./Counter-22dbd44c.js";
import { G as GuestLayout } from "./GuestLayout-98337e8a.js";
import { u as useCart } from "./cart-ae7434ff.js";
import axios from "axios";
import "@vue/reactivity";
import "@vue/runtime-core";
import "pinia";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Index",
  __ssrInlineRender: true,
  setup(__props) {
    const cart = useCart();
    const totalPrice = computed(() => {
      let price = 0;
      cart.products.forEach((item) => {
        price += item.price;
      });
      return price;
    });
    function checkoutCart() {
      axios.post(route("checkout.checkoutCart")).then((res) => {
        Swal.fire({
          title: "Checkout successful!",
          icon: "success"
        }).then(
          () => router.visit(route("product.archive"))
        );
        cart.$reset();
      });
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_container = resolveComponent("v-container");
      const _component_v_btn = resolveComponent("v-btn");
      const _component_v_row = resolveComponent("v-row");
      const _component_v_col = resolveComponent("v-col");
      const _component_v_card = resolveComponent("v-card");
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_list = resolveComponent("v-list");
      const _component_v_list_item = resolveComponent("v-list-item");
      const _component_v_list_item_title = resolveComponent("v-list-item-title");
      const _component_v_list_item_subtitle = resolveComponent("v-list-item-subtitle");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Checkout" }, null, _parent));
      _push(ssrRenderComponent(GuestLayout, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_container, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("product.archive")
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_v_btn, {
                          icon: "mdi-arrow-left",
                          variant: "plain"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_v_btn, {
                            icon: "mdi-arrow-left",
                            variant: "plain"
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_v_row, null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_v_col, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_v_card, null, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_v_card_title, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(` Your Orders: `);
                                        } else {
                                          return [
                                            createTextVNode(" Your Orders: ")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_v_card_text, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          if (unref(cart).products.length > 0) {
                                            _push7(ssrRenderComponent(_component_v_list, null, {
                                              default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(`<!--[-->`);
                                                  ssrRenderList(unref(cart).products, (product, key) => {
                                                    _push8(ssrRenderComponent(_component_v_list_item, {
                                                      key: product.id
                                                    }, {
                                                      prepend: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                        if (_push9) {
                                                          _push9(ssrRenderComponent(_component_v_btn, {
                                                            icon: "mdi-close",
                                                            onClick: ($event) => unref(cart).removeProduct(key),
                                                            variant: "plain"
                                                          }, null, _parent9, _scopeId8));
                                                        } else {
                                                          return [
                                                            createVNode(_component_v_btn, {
                                                              icon: "mdi-close",
                                                              onClick: ($event) => unref(cart).removeProduct(key),
                                                              variant: "plain"
                                                            }, null, 8, ["onClick"])
                                                          ];
                                                        }
                                                      }),
                                                      append: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                        if (_push9) {
                                                          _push9(ssrRenderComponent(Counter, {
                                                            modelValue: unref(cart).products[key].quantity,
                                                            "onUpdate:modelValue": [($event) => unref(cart).products[key].quantity = $event, ($event) => unref(cart).changeQuantity(key)]
                                                          }, null, _parent9, _scopeId8));
                                                        } else {
                                                          return [
                                                            createVNode(Counter, {
                                                              modelValue: unref(cart).products[key].quantity,
                                                              "onUpdate:modelValue": [($event) => unref(cart).products[key].quantity = $event, ($event) => unref(cart).changeQuantity(key)]
                                                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                          ];
                                                        }
                                                      }),
                                                      default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                        if (_push9) {
                                                          _push9(ssrRenderComponent(_component_v_list_item_title, null, {
                                                            default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                              if (_push10) {
                                                                _push10(`${ssrInterpolate(product.name)}`);
                                                              } else {
                                                                return [
                                                                  createTextVNode(toDisplayString(product.name), 1)
                                                                ];
                                                              }
                                                            }),
                                                            _: 2
                                                          }, _parent9, _scopeId8));
                                                          _push9(ssrRenderComponent(_component_v_list_item_subtitle, null, {
                                                            default: withCtx((_9, _push10, _parent10, _scopeId9) => {
                                                              if (_push10) {
                                                                _push10(`$${ssrInterpolate(product.price)}`);
                                                              } else {
                                                                return [
                                                                  createTextVNode("$" + toDisplayString(product.price), 1)
                                                                ];
                                                              }
                                                            }),
                                                            _: 2
                                                          }, _parent9, _scopeId8));
                                                        } else {
                                                          return [
                                                            createVNode(_component_v_list_item_title, null, {
                                                              default: withCtx(() => [
                                                                createTextVNode(toDisplayString(product.name), 1)
                                                              ]),
                                                              _: 2
                                                            }, 1024),
                                                            createVNode(_component_v_list_item_subtitle, null, {
                                                              default: withCtx(() => [
                                                                createTextVNode("$" + toDisplayString(product.price), 1)
                                                              ]),
                                                              _: 2
                                                            }, 1024)
                                                          ];
                                                        }
                                                      }),
                                                      _: 2
                                                    }, _parent8, _scopeId7));
                                                  });
                                                  _push8(`<!--]-->`);
                                                } else {
                                                  return [
                                                    (openBlock(true), createBlock(Fragment, null, renderList(unref(cart).products, (product, key) => {
                                                      return openBlock(), createBlock(_component_v_list_item, {
                                                        key: product.id
                                                      }, {
                                                        prepend: withCtx(() => [
                                                          createVNode(_component_v_btn, {
                                                            icon: "mdi-close",
                                                            onClick: ($event) => unref(cart).removeProduct(key),
                                                            variant: "plain"
                                                          }, null, 8, ["onClick"])
                                                        ]),
                                                        append: withCtx(() => [
                                                          createVNode(Counter, {
                                                            modelValue: unref(cart).products[key].quantity,
                                                            "onUpdate:modelValue": [($event) => unref(cart).products[key].quantity = $event, ($event) => unref(cart).changeQuantity(key)]
                                                          }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                        ]),
                                                        default: withCtx(() => [
                                                          createVNode(_component_v_list_item_title, null, {
                                                            default: withCtx(() => [
                                                              createTextVNode(toDisplayString(product.name), 1)
                                                            ]),
                                                            _: 2
                                                          }, 1024),
                                                          createVNode(_component_v_list_item_subtitle, null, {
                                                            default: withCtx(() => [
                                                              createTextVNode("$" + toDisplayString(product.price), 1)
                                                            ]),
                                                            _: 2
                                                          }, 1024)
                                                        ]),
                                                        _: 2
                                                      }, 1024);
                                                    }), 128))
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent7, _scopeId6));
                                          } else {
                                            _push7(`<p${_scopeId6}> Cart is Empty! Please Add to Cart!</p>`);
                                          }
                                        } else {
                                          return [
                                            unref(cart).products.length > 0 ? (openBlock(), createBlock(_component_v_list, { key: 0 }, {
                                              default: withCtx(() => [
                                                (openBlock(true), createBlock(Fragment, null, renderList(unref(cart).products, (product, key) => {
                                                  return openBlock(), createBlock(_component_v_list_item, {
                                                    key: product.id
                                                  }, {
                                                    prepend: withCtx(() => [
                                                      createVNode(_component_v_btn, {
                                                        icon: "mdi-close",
                                                        onClick: ($event) => unref(cart).removeProduct(key),
                                                        variant: "plain"
                                                      }, null, 8, ["onClick"])
                                                    ]),
                                                    append: withCtx(() => [
                                                      createVNode(Counter, {
                                                        modelValue: unref(cart).products[key].quantity,
                                                        "onUpdate:modelValue": [($event) => unref(cart).products[key].quantity = $event, ($event) => unref(cart).changeQuantity(key)]
                                                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                    ]),
                                                    default: withCtx(() => [
                                                      createVNode(_component_v_list_item_title, null, {
                                                        default: withCtx(() => [
                                                          createTextVNode(toDisplayString(product.name), 1)
                                                        ]),
                                                        _: 2
                                                      }, 1024),
                                                      createVNode(_component_v_list_item_subtitle, null, {
                                                        default: withCtx(() => [
                                                          createTextVNode("$" + toDisplayString(product.price), 1)
                                                        ]),
                                                        _: 2
                                                      }, 1024)
                                                    ]),
                                                    _: 2
                                                  }, 1024);
                                                }), 128))
                                              ]),
                                              _: 1
                                            })) : (openBlock(), createBlock("p", { key: 1 }, " Cart is Empty! Please Add to Cart!"))
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_v_card_title, null, {
                                        default: withCtx(() => [
                                          createTextVNode(" Your Orders: ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_v_card_text, null, {
                                        default: withCtx(() => [
                                          unref(cart).products.length > 0 ? (openBlock(), createBlock(_component_v_list, { key: 0 }, {
                                            default: withCtx(() => [
                                              (openBlock(true), createBlock(Fragment, null, renderList(unref(cart).products, (product, key) => {
                                                return openBlock(), createBlock(_component_v_list_item, {
                                                  key: product.id
                                                }, {
                                                  prepend: withCtx(() => [
                                                    createVNode(_component_v_btn, {
                                                      icon: "mdi-close",
                                                      onClick: ($event) => unref(cart).removeProduct(key),
                                                      variant: "plain"
                                                    }, null, 8, ["onClick"])
                                                  ]),
                                                  append: withCtx(() => [
                                                    createVNode(Counter, {
                                                      modelValue: unref(cart).products[key].quantity,
                                                      "onUpdate:modelValue": [($event) => unref(cart).products[key].quantity = $event, ($event) => unref(cart).changeQuantity(key)]
                                                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                  ]),
                                                  default: withCtx(() => [
                                                    createVNode(_component_v_list_item_title, null, {
                                                      default: withCtx(() => [
                                                        createTextVNode(toDisplayString(product.name), 1)
                                                      ]),
                                                      _: 2
                                                    }, 1024),
                                                    createVNode(_component_v_list_item_subtitle, null, {
                                                      default: withCtx(() => [
                                                        createTextVNode("$" + toDisplayString(product.price), 1)
                                                      ]),
                                                      _: 2
                                                    }, 1024)
                                                  ]),
                                                  _: 2
                                                }, 1024);
                                              }), 128))
                                            ]),
                                            _: 1
                                          })) : (openBlock(), createBlock("p", { key: 1 }, " Cart is Empty! Please Add to Cart!"))
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_v_card, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_v_card_title, null, {
                                      default: withCtx(() => [
                                        createTextVNode(" Your Orders: ")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_v_card_text, null, {
                                      default: withCtx(() => [
                                        unref(cart).products.length > 0 ? (openBlock(), createBlock(_component_v_list, { key: 0 }, {
                                          default: withCtx(() => [
                                            (openBlock(true), createBlock(Fragment, null, renderList(unref(cart).products, (product, key) => {
                                              return openBlock(), createBlock(_component_v_list_item, {
                                                key: product.id
                                              }, {
                                                prepend: withCtx(() => [
                                                  createVNode(_component_v_btn, {
                                                    icon: "mdi-close",
                                                    onClick: ($event) => unref(cart).removeProduct(key),
                                                    variant: "plain"
                                                  }, null, 8, ["onClick"])
                                                ]),
                                                append: withCtx(() => [
                                                  createVNode(Counter, {
                                                    modelValue: unref(cart).products[key].quantity,
                                                    "onUpdate:modelValue": [($event) => unref(cart).products[key].quantity = $event, ($event) => unref(cart).changeQuantity(key)]
                                                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                                ]),
                                                default: withCtx(() => [
                                                  createVNode(_component_v_list_item_title, null, {
                                                    default: withCtx(() => [
                                                      createTextVNode(toDisplayString(product.name), 1)
                                                    ]),
                                                    _: 2
                                                  }, 1024),
                                                  createVNode(_component_v_list_item_subtitle, null, {
                                                    default: withCtx(() => [
                                                      createTextVNode("$" + toDisplayString(product.price), 1)
                                                    ]),
                                                    _: 2
                                                  }, 1024)
                                                ]),
                                                _: 2
                                              }, 1024);
                                            }), 128))
                                          ]),
                                          _: 1
                                        })) : (openBlock(), createBlock("p", { key: 1 }, " Cart is Empty! Please Add to Cart!"))
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_v_col, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_v_card, null, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(ssrRenderComponent(_component_v_card_title, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(` Checkout `);
                                        } else {
                                          return [
                                            createTextVNode(" Checkout ")
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_v_card_text, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          _push7(`<h1${_scopeId6}>Total Price:</h1><p${_scopeId6}>$${ssrInterpolate(totalPrice.value)}</p>`);
                                        } else {
                                          return [
                                            createVNode("h1", null, "Total Price:"),
                                            createVNode("p", null, "$" + toDisplayString(totalPrice.value), 1)
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                    _push6(ssrRenderComponent(_component_v_card_actions, null, {
                                      default: withCtx((_6, _push7, _parent7, _scopeId6) => {
                                        if (_push7) {
                                          if (_ctx.$page.props.auth.user) {
                                            _push7(ssrRenderComponent(_component_v_btn, {
                                              color: "primary",
                                              variant: "elevated",
                                              block: "",
                                              onClick: checkoutCart
                                            }, {
                                              default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(` Checkout `);
                                                } else {
                                                  return [
                                                    createTextVNode(" Checkout ")
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent7, _scopeId6));
                                          } else {
                                            _push7(ssrRenderComponent(unref(Link), {
                                              href: _ctx.route("login"),
                                              class: "min-w-[100%]"
                                            }, {
                                              default: withCtx((_7, _push8, _parent8, _scopeId7) => {
                                                if (_push8) {
                                                  _push8(ssrRenderComponent(_component_v_btn, {
                                                    color: "warning",
                                                    variant: "elevated",
                                                    block: ""
                                                  }, {
                                                    default: withCtx((_8, _push9, _parent9, _scopeId8) => {
                                                      if (_push9) {
                                                        _push9(` Login to Checkout `);
                                                      } else {
                                                        return [
                                                          createTextVNode(" Login to Checkout ")
                                                        ];
                                                      }
                                                    }),
                                                    _: 1
                                                  }, _parent8, _scopeId7));
                                                } else {
                                                  return [
                                                    createVNode(_component_v_btn, {
                                                      color: "warning",
                                                      variant: "elevated",
                                                      block: ""
                                                    }, {
                                                      default: withCtx(() => [
                                                        createTextVNode(" Login to Checkout ")
                                                      ]),
                                                      _: 1
                                                    })
                                                  ];
                                                }
                                              }),
                                              _: 1
                                            }, _parent7, _scopeId6));
                                          }
                                        } else {
                                          return [
                                            _ctx.$page.props.auth.user ? (openBlock(), createBlock(_component_v_btn, {
                                              key: 0,
                                              color: "primary",
                                              variant: "elevated",
                                              block: "",
                                              onClick: checkoutCart
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(" Checkout ")
                                              ]),
                                              _: 1
                                            })) : (openBlock(), createBlock(unref(Link), {
                                              key: 1,
                                              href: _ctx.route("login"),
                                              class: "min-w-[100%]"
                                            }, {
                                              default: withCtx(() => [
                                                createVNode(_component_v_btn, {
                                                  color: "warning",
                                                  variant: "elevated",
                                                  block: ""
                                                }, {
                                                  default: withCtx(() => [
                                                    createTextVNode(" Login to Checkout ")
                                                  ]),
                                                  _: 1
                                                })
                                              ]),
                                              _: 1
                                            }, 8, ["href"]))
                                          ];
                                        }
                                      }),
                                      _: 1
                                    }, _parent6, _scopeId5));
                                  } else {
                                    return [
                                      createVNode(_component_v_card_title, null, {
                                        default: withCtx(() => [
                                          createTextVNode(" Checkout ")
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_v_card_text, null, {
                                        default: withCtx(() => [
                                          createVNode("h1", null, "Total Price:"),
                                          createVNode("p", null, "$" + toDisplayString(totalPrice.value), 1)
                                        ]),
                                        _: 1
                                      }),
                                      createVNode(_component_v_card_actions, null, {
                                        default: withCtx(() => [
                                          _ctx.$page.props.auth.user ? (openBlock(), createBlock(_component_v_btn, {
                                            key: 0,
                                            color: "primary",
                                            variant: "elevated",
                                            block: "",
                                            onClick: checkoutCart
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(" Checkout ")
                                            ]),
                                            _: 1
                                          })) : (openBlock(), createBlock(unref(Link), {
                                            key: 1,
                                            href: _ctx.route("login"),
                                            class: "min-w-[100%]"
                                          }, {
                                            default: withCtx(() => [
                                              createVNode(_component_v_btn, {
                                                color: "warning",
                                                variant: "elevated",
                                                block: ""
                                              }, {
                                                default: withCtx(() => [
                                                  createTextVNode(" Login to Checkout ")
                                                ]),
                                                _: 1
                                              })
                                            ]),
                                            _: 1
                                          }, 8, ["href"]))
                                        ]),
                                        _: 1
                                      })
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_v_card, null, {
                                  default: withCtx(() => [
                                    createVNode(_component_v_card_title, null, {
                                      default: withCtx(() => [
                                        createTextVNode(" Checkout ")
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_v_card_text, null, {
                                      default: withCtx(() => [
                                        createVNode("h1", null, "Total Price:"),
                                        createVNode("p", null, "$" + toDisplayString(totalPrice.value), 1)
                                      ]),
                                      _: 1
                                    }),
                                    createVNode(_component_v_card_actions, null, {
                                      default: withCtx(() => [
                                        _ctx.$page.props.auth.user ? (openBlock(), createBlock(_component_v_btn, {
                                          key: 0,
                                          color: "primary",
                                          variant: "elevated",
                                          block: "",
                                          onClick: checkoutCart
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Checkout ")
                                          ]),
                                          _: 1
                                        })) : (openBlock(), createBlock(unref(Link), {
                                          key: 1,
                                          href: _ctx.route("login"),
                                          class: "min-w-[100%]"
                                        }, {
                                          default: withCtx(() => [
                                            createVNode(_component_v_btn, {
                                              color: "warning",
                                              variant: "elevated",
                                              block: ""
                                            }, {
                                              default: withCtx(() => [
                                                createTextVNode(" Login to Checkout ")
                                              ]),
                                              _: 1
                                            })
                                          ]),
                                          _: 1
                                        }, 8, ["href"]))
                                      ]),
                                      _: 1
                                    })
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_v_col, null, {
                            default: withCtx(() => [
                              createVNode(_component_v_card, null, {
                                default: withCtx(() => [
                                  createVNode(_component_v_card_title, null, {
                                    default: withCtx(() => [
                                      createTextVNode(" Your Orders: ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_text, null, {
                                    default: withCtx(() => [
                                      unref(cart).products.length > 0 ? (openBlock(), createBlock(_component_v_list, { key: 0 }, {
                                        default: withCtx(() => [
                                          (openBlock(true), createBlock(Fragment, null, renderList(unref(cart).products, (product, key) => {
                                            return openBlock(), createBlock(_component_v_list_item, {
                                              key: product.id
                                            }, {
                                              prepend: withCtx(() => [
                                                createVNode(_component_v_btn, {
                                                  icon: "mdi-close",
                                                  onClick: ($event) => unref(cart).removeProduct(key),
                                                  variant: "plain"
                                                }, null, 8, ["onClick"])
                                              ]),
                                              append: withCtx(() => [
                                                createVNode(Counter, {
                                                  modelValue: unref(cart).products[key].quantity,
                                                  "onUpdate:modelValue": [($event) => unref(cart).products[key].quantity = $event, ($event) => unref(cart).changeQuantity(key)]
                                                }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                              ]),
                                              default: withCtx(() => [
                                                createVNode(_component_v_list_item_title, null, {
                                                  default: withCtx(() => [
                                                    createTextVNode(toDisplayString(product.name), 1)
                                                  ]),
                                                  _: 2
                                                }, 1024),
                                                createVNode(_component_v_list_item_subtitle, null, {
                                                  default: withCtx(() => [
                                                    createTextVNode("$" + toDisplayString(product.price), 1)
                                                  ]),
                                                  _: 2
                                                }, 1024)
                                              ]),
                                              _: 2
                                            }, 1024);
                                          }), 128))
                                        ]),
                                        _: 1
                                      })) : (openBlock(), createBlock("p", { key: 1 }, " Cart is Empty! Please Add to Cart!"))
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }),
                          createVNode(_component_v_col, null, {
                            default: withCtx(() => [
                              createVNode(_component_v_card, null, {
                                default: withCtx(() => [
                                  createVNode(_component_v_card_title, null, {
                                    default: withCtx(() => [
                                      createTextVNode(" Checkout ")
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_text, null, {
                                    default: withCtx(() => [
                                      createVNode("h1", null, "Total Price:"),
                                      createVNode("p", null, "$" + toDisplayString(totalPrice.value), 1)
                                    ]),
                                    _: 1
                                  }),
                                  createVNode(_component_v_card_actions, null, {
                                    default: withCtx(() => [
                                      _ctx.$page.props.auth.user ? (openBlock(), createBlock(_component_v_btn, {
                                        key: 0,
                                        color: "primary",
                                        variant: "elevated",
                                        block: "",
                                        onClick: checkoutCart
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Checkout ")
                                        ]),
                                        _: 1
                                      })) : (openBlock(), createBlock(unref(Link), {
                                        key: 1,
                                        href: _ctx.route("login"),
                                        class: "min-w-[100%]"
                                      }, {
                                        default: withCtx(() => [
                                          createVNode(_component_v_btn, {
                                            color: "warning",
                                            variant: "elevated",
                                            block: ""
                                          }, {
                                            default: withCtx(() => [
                                              createTextVNode(" Login to Checkout ")
                                            ]),
                                            _: 1
                                          })
                                        ]),
                                        _: 1
                                      }, 8, ["href"]))
                                    ]),
                                    _: 1
                                  })
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(unref(Link), {
                      href: _ctx.route("product.archive")
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, {
                          icon: "mdi-arrow-left",
                          variant: "plain"
                        })
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_component_v_row, null, {
                      default: withCtx(() => [
                        createVNode(_component_v_col, null, {
                          default: withCtx(() => [
                            createVNode(_component_v_card, null, {
                              default: withCtx(() => [
                                createVNode(_component_v_card_title, null, {
                                  default: withCtx(() => [
                                    createTextVNode(" Your Orders: ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_v_card_text, null, {
                                  default: withCtx(() => [
                                    unref(cart).products.length > 0 ? (openBlock(), createBlock(_component_v_list, { key: 0 }, {
                                      default: withCtx(() => [
                                        (openBlock(true), createBlock(Fragment, null, renderList(unref(cart).products, (product, key) => {
                                          return openBlock(), createBlock(_component_v_list_item, {
                                            key: product.id
                                          }, {
                                            prepend: withCtx(() => [
                                              createVNode(_component_v_btn, {
                                                icon: "mdi-close",
                                                onClick: ($event) => unref(cart).removeProduct(key),
                                                variant: "plain"
                                              }, null, 8, ["onClick"])
                                            ]),
                                            append: withCtx(() => [
                                              createVNode(Counter, {
                                                modelValue: unref(cart).products[key].quantity,
                                                "onUpdate:modelValue": [($event) => unref(cart).products[key].quantity = $event, ($event) => unref(cart).changeQuantity(key)]
                                              }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                            ]),
                                            default: withCtx(() => [
                                              createVNode(_component_v_list_item_title, null, {
                                                default: withCtx(() => [
                                                  createTextVNode(toDisplayString(product.name), 1)
                                                ]),
                                                _: 2
                                              }, 1024),
                                              createVNode(_component_v_list_item_subtitle, null, {
                                                default: withCtx(() => [
                                                  createTextVNode("$" + toDisplayString(product.price), 1)
                                                ]),
                                                _: 2
                                              }, 1024)
                                            ]),
                                            _: 2
                                          }, 1024);
                                        }), 128))
                                      ]),
                                      _: 1
                                    })) : (openBlock(), createBlock("p", { key: 1 }, " Cart is Empty! Please Add to Cart!"))
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }),
                        createVNode(_component_v_col, null, {
                          default: withCtx(() => [
                            createVNode(_component_v_card, null, {
                              default: withCtx(() => [
                                createVNode(_component_v_card_title, null, {
                                  default: withCtx(() => [
                                    createTextVNode(" Checkout ")
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_v_card_text, null, {
                                  default: withCtx(() => [
                                    createVNode("h1", null, "Total Price:"),
                                    createVNode("p", null, "$" + toDisplayString(totalPrice.value), 1)
                                  ]),
                                  _: 1
                                }),
                                createVNode(_component_v_card_actions, null, {
                                  default: withCtx(() => [
                                    _ctx.$page.props.auth.user ? (openBlock(), createBlock(_component_v_btn, {
                                      key: 0,
                                      color: "primary",
                                      variant: "elevated",
                                      block: "",
                                      onClick: checkoutCart
                                    }, {
                                      default: withCtx(() => [
                                        createTextVNode(" Checkout ")
                                      ]),
                                      _: 1
                                    })) : (openBlock(), createBlock(unref(Link), {
                                      key: 1,
                                      href: _ctx.route("login"),
                                      class: "min-w-[100%]"
                                    }, {
                                      default: withCtx(() => [
                                        createVNode(_component_v_btn, {
                                          color: "warning",
                                          variant: "elevated",
                                          block: ""
                                        }, {
                                          default: withCtx(() => [
                                            createTextVNode(" Login to Checkout ")
                                          ]),
                                          _: 1
                                        })
                                      ]),
                                      _: 1
                                    }, 8, ["href"]))
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_container, null, {
                default: withCtx(() => [
                  createVNode(unref(Link), {
                    href: _ctx.route("product.archive")
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, {
                        icon: "mdi-arrow-left",
                        variant: "plain"
                      })
                    ]),
                    _: 1
                  }, 8, ["href"]),
                  createVNode(_component_v_row, null, {
                    default: withCtx(() => [
                      createVNode(_component_v_col, null, {
                        default: withCtx(() => [
                          createVNode(_component_v_card, null, {
                            default: withCtx(() => [
                              createVNode(_component_v_card_title, null, {
                                default: withCtx(() => [
                                  createTextVNode(" Your Orders: ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_card_text, null, {
                                default: withCtx(() => [
                                  unref(cart).products.length > 0 ? (openBlock(), createBlock(_component_v_list, { key: 0 }, {
                                    default: withCtx(() => [
                                      (openBlock(true), createBlock(Fragment, null, renderList(unref(cart).products, (product, key) => {
                                        return openBlock(), createBlock(_component_v_list_item, {
                                          key: product.id
                                        }, {
                                          prepend: withCtx(() => [
                                            createVNode(_component_v_btn, {
                                              icon: "mdi-close",
                                              onClick: ($event) => unref(cart).removeProduct(key),
                                              variant: "plain"
                                            }, null, 8, ["onClick"])
                                          ]),
                                          append: withCtx(() => [
                                            createVNode(Counter, {
                                              modelValue: unref(cart).products[key].quantity,
                                              "onUpdate:modelValue": [($event) => unref(cart).products[key].quantity = $event, ($event) => unref(cart).changeQuantity(key)]
                                            }, null, 8, ["modelValue", "onUpdate:modelValue"])
                                          ]),
                                          default: withCtx(() => [
                                            createVNode(_component_v_list_item_title, null, {
                                              default: withCtx(() => [
                                                createTextVNode(toDisplayString(product.name), 1)
                                              ]),
                                              _: 2
                                            }, 1024),
                                            createVNode(_component_v_list_item_subtitle, null, {
                                              default: withCtx(() => [
                                                createTextVNode("$" + toDisplayString(product.price), 1)
                                              ]),
                                              _: 2
                                            }, 1024)
                                          ]),
                                          _: 2
                                        }, 1024);
                                      }), 128))
                                    ]),
                                    _: 1
                                  })) : (openBlock(), createBlock("p", { key: 1 }, " Cart is Empty! Please Add to Cart!"))
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      }),
                      createVNode(_component_v_col, null, {
                        default: withCtx(() => [
                          createVNode(_component_v_card, null, {
                            default: withCtx(() => [
                              createVNode(_component_v_card_title, null, {
                                default: withCtx(() => [
                                  createTextVNode(" Checkout ")
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_card_text, null, {
                                default: withCtx(() => [
                                  createVNode("h1", null, "Total Price:"),
                                  createVNode("p", null, "$" + toDisplayString(totalPrice.value), 1)
                                ]),
                                _: 1
                              }),
                              createVNode(_component_v_card_actions, null, {
                                default: withCtx(() => [
                                  _ctx.$page.props.auth.user ? (openBlock(), createBlock(_component_v_btn, {
                                    key: 0,
                                    color: "primary",
                                    variant: "elevated",
                                    block: "",
                                    onClick: checkoutCart
                                  }, {
                                    default: withCtx(() => [
                                      createTextVNode(" Checkout ")
                                    ]),
                                    _: 1
                                  })) : (openBlock(), createBlock(unref(Link), {
                                    key: 1,
                                    href: _ctx.route("login"),
                                    class: "min-w-[100%]"
                                  }, {
                                    default: withCtx(() => [
                                      createVNode(_component_v_btn, {
                                        color: "warning",
                                        variant: "elevated",
                                        block: ""
                                      }, {
                                        default: withCtx(() => [
                                          createTextVNode(" Login to Checkout ")
                                        ]),
                                        _: 1
                                      })
                                    ]),
                                    _: 1
                                  }, 8, ["href"]))
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          })
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Checkout/Index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
