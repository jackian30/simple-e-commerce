import { defineComponent, reactive, computed, resolveComponent, unref, withCtx, createTextVNode, createVNode, openBlock, createBlock, toDisplayString, createCommentVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { useVuelidate } from "@vuelidate/core";
import { required, email } from "@vuelidate/validators";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { u as useCart } from "./cart-ae7434ff.js";
import { L as Layout, C as CustomInput, g as generateErrors } from "./errorGenerator-448112f0.js";
import "axios";
import "pinia";
import "@vue/reactivity";
import "@vue/runtime-core";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Login",
  __ssrInlineRender: true,
  props: {
    canResetPassword: { type: Boolean },
    status: {}
  },
  setup(__props) {
    const cart = useCart();
    const form = useForm({
      email: "",
      password: "",
      remember: false
    });
    const $externalResults = reactive({});
    const rules = computed(() => ({
      email: {
        required,
        email
      },
      password: {
        required
      }
    }));
    const v$ = useVuelidate(rules, form, { $externalResults });
    const submit = async () => {
      await v$.value.$touch();
      if (v$.value.$invalid) {
        return await false;
      }
      form.post(route("login"), {
        onFinish: async () => {
          await cart.getExistingCart();
          form.reset("password");
        },
        onError: async (err) => {
          await Object.keys(err).forEach((item) => {
            $externalResults[item] = err[item];
          });
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_form = resolveComponent("v-form");
      const _component_v_checkbox = resolveComponent("v-checkbox");
      const _component_v_btn = resolveComponent("v-btn");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Log in" }, null, _parent));
      _push(ssrRenderComponent(Layout, {
        isLoading: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_card_text, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="grid place-items-center mb-[20px]"${_scopeId2}></div>`);
                  if (_ctx.status) {
                    _push3(`<div class="mb-4 font-medium text-sm text-green-600"${_scopeId2}>${ssrInterpolate(_ctx.status)}</div>`);
                  } else {
                    _push3(`<!---->`);
                  }
                  _push3(ssrRenderComponent(_component_v_form, { onSubmit: submit }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).email,
                          "onUpdate:modelValue": ($event) => unref(form).email = $event,
                          errorMessages: unref(generateErrors)(unref(v$).email),
                          label: "E-mail",
                          required: "",
                          type: "email",
                          onInput: ($event) => unref(v$).email.$touch(),
                          onBlur: ($event) => unref(v$).email.$touch()
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).password,
                          "onUpdate:modelValue": ($event) => unref(form).password = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password),
                          label: "Password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password.$touch(),
                          onBlur: ($event) => unref(v$).password.$touch(),
                          class: "mt-[20px]"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(_component_v_checkbox, {
                          modelValue: unref(form).remember,
                          "onUpdate:modelValue": ($event) => unref(form).remember = $event,
                          label: "Remember me",
                          dense: ""
                        }, null, _parent4, _scopeId3));
                        _push4(`<div class="grid grid-cols-2 gap-4"${_scopeId3}>`);
                        _push4(ssrRenderComponent(_component_v_btn, {
                          rounded: "pill",
                          color: "primary",
                          style: { "color": "white" },
                          type: "submit",
                          loading: unref(form).processing
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(` Sign In `);
                            } else {
                              return [
                                createTextVNode(" Sign In ")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(unref(Link), {
                          href: _ctx.route("register")
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(ssrRenderComponent(_component_v_btn, {
                                rounded: "pill",
                                color: "primary",
                                variant: "outlined",
                                "min-width": "100%"
                              }, {
                                default: withCtx((_5, _push6, _parent6, _scopeId5) => {
                                  if (_push6) {
                                    _push6(`Register `);
                                  } else {
                                    return [
                                      createTextVNode("Register ")
                                    ];
                                  }
                                }),
                                _: 1
                              }, _parent5, _scopeId4));
                            } else {
                              return [
                                createVNode(_component_v_btn, {
                                  rounded: "pill",
                                  color: "primary",
                                  variant: "outlined",
                                  "min-width": "100%"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Register ")
                                  ]),
                                  _: 1
                                })
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                        _push4(`</div>`);
                        _push4(ssrRenderComponent(unref(Link), {
                          href: _ctx.route("password.request"),
                          class: "grid place-items-center mt-[20px] text-[10px] not-italic font-normal leading-[7px text-[#5D5FEF]"
                        }, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(` Forgot your password? `);
                            } else {
                              return [
                                createTextVNode(" Forgot your password? ")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(CustomInput, {
                            modelValue: unref(form).email,
                            "onUpdate:modelValue": ($event) => unref(form).email = $event,
                            errorMessages: unref(generateErrors)(unref(v$).email),
                            label: "E-mail",
                            required: "",
                            type: "email",
                            onInput: ($event) => unref(v$).email.$touch(),
                            onBlur: ($event) => unref(v$).email.$touch()
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                          createVNode(CustomInput, {
                            modelValue: unref(form).password,
                            "onUpdate:modelValue": ($event) => unref(form).password = $event,
                            errorMessages: unref(generateErrors)(unref(v$).password),
                            label: "Password",
                            required: "",
                            type: "password",
                            outlined: "",
                            onInput: ($event) => unref(v$).password.$touch(),
                            onBlur: ($event) => unref(v$).password.$touch(),
                            class: "mt-[20px]"
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                          createVNode(_component_v_checkbox, {
                            modelValue: unref(form).remember,
                            "onUpdate:modelValue": ($event) => unref(form).remember = $event,
                            label: "Remember me",
                            dense: ""
                          }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                          createVNode("div", { class: "grid grid-cols-2 gap-4" }, [
                            createVNode(_component_v_btn, {
                              rounded: "pill",
                              color: "primary",
                              style: { "color": "white" },
                              type: "submit",
                              loading: unref(form).processing
                            }, {
                              default: withCtx(() => [
                                createTextVNode(" Sign In ")
                              ]),
                              _: 1
                            }, 8, ["loading"]),
                            createVNode(unref(Link), {
                              href: _ctx.route("register")
                            }, {
                              default: withCtx(() => [
                                createVNode(_component_v_btn, {
                                  rounded: "pill",
                                  color: "primary",
                                  variant: "outlined",
                                  "min-width": "100%"
                                }, {
                                  default: withCtx(() => [
                                    createTextVNode("Register ")
                                  ]),
                                  _: 1
                                })
                              ]),
                              _: 1
                            }, 8, ["href"])
                          ]),
                          createVNode(unref(Link), {
                            href: _ctx.route("password.request"),
                            class: "grid place-items-center mt-[20px] text-[10px] not-italic font-normal leading-[7px text-[#5D5FEF]"
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Forgot your password? ")
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("div", { class: "grid place-items-center mb-[20px]" }),
                    _ctx.status ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "mb-4 font-medium text-sm text-green-600"
                    }, toDisplayString(_ctx.status), 1)) : createCommentVNode("", true),
                    createVNode(_component_v_form, {
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(CustomInput, {
                          modelValue: unref(form).email,
                          "onUpdate:modelValue": ($event) => unref(form).email = $event,
                          errorMessages: unref(generateErrors)(unref(v$).email),
                          label: "E-mail",
                          required: "",
                          type: "email",
                          onInput: ($event) => unref(v$).email.$touch(),
                          onBlur: ($event) => unref(v$).email.$touch()
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                        createVNode(CustomInput, {
                          modelValue: unref(form).password,
                          "onUpdate:modelValue": ($event) => unref(form).password = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password),
                          label: "Password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password.$touch(),
                          onBlur: ($event) => unref(v$).password.$touch(),
                          class: "mt-[20px]"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                        createVNode(_component_v_checkbox, {
                          modelValue: unref(form).remember,
                          "onUpdate:modelValue": ($event) => unref(form).remember = $event,
                          label: "Remember me",
                          dense: ""
                        }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                        createVNode("div", { class: "grid grid-cols-2 gap-4" }, [
                          createVNode(_component_v_btn, {
                            rounded: "pill",
                            color: "primary",
                            style: { "color": "white" },
                            type: "submit",
                            loading: unref(form).processing
                          }, {
                            default: withCtx(() => [
                              createTextVNode(" Sign In ")
                            ]),
                            _: 1
                          }, 8, ["loading"]),
                          createVNode(unref(Link), {
                            href: _ctx.route("register")
                          }, {
                            default: withCtx(() => [
                              createVNode(_component_v_btn, {
                                rounded: "pill",
                                color: "primary",
                                variant: "outlined",
                                "min-width": "100%"
                              }, {
                                default: withCtx(() => [
                                  createTextVNode("Register ")
                                ]),
                                _: 1
                              })
                            ]),
                            _: 1
                          }, 8, ["href"])
                        ]),
                        createVNode(unref(Link), {
                          href: _ctx.route("password.request"),
                          class: "grid place-items-center mt-[20px] text-[10px] not-italic font-normal leading-[7px text-[#5D5FEF]"
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Forgot your password? ")
                          ]),
                          _: 1
                        }, 8, ["href"])
                      ]),
                      _: 1
                    }, 8, ["onSubmit"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createVNode("div", { class: "grid place-items-center mb-[20px]" }),
                  _ctx.status ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "mb-4 font-medium text-sm text-green-600"
                  }, toDisplayString(_ctx.status), 1)) : createCommentVNode("", true),
                  createVNode(_component_v_form, {
                    onSubmit: withModifiers(submit, ["prevent"])
                  }, {
                    default: withCtx(() => [
                      createVNode(CustomInput, {
                        modelValue: unref(form).email,
                        "onUpdate:modelValue": ($event) => unref(form).email = $event,
                        errorMessages: unref(generateErrors)(unref(v$).email),
                        label: "E-mail",
                        required: "",
                        type: "email",
                        onInput: ($event) => unref(v$).email.$touch(),
                        onBlur: ($event) => unref(v$).email.$touch()
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                      createVNode(CustomInput, {
                        modelValue: unref(form).password,
                        "onUpdate:modelValue": ($event) => unref(form).password = $event,
                        errorMessages: unref(generateErrors)(unref(v$).password),
                        label: "Password",
                        required: "",
                        type: "password",
                        outlined: "",
                        onInput: ($event) => unref(v$).password.$touch(),
                        onBlur: ($event) => unref(v$).password.$touch(),
                        class: "mt-[20px]"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                      createVNode(_component_v_checkbox, {
                        modelValue: unref(form).remember,
                        "onUpdate:modelValue": ($event) => unref(form).remember = $event,
                        label: "Remember me",
                        dense: ""
                      }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                      createVNode("div", { class: "grid grid-cols-2 gap-4" }, [
                        createVNode(_component_v_btn, {
                          rounded: "pill",
                          color: "primary",
                          style: { "color": "white" },
                          type: "submit",
                          loading: unref(form).processing
                        }, {
                          default: withCtx(() => [
                            createTextVNode(" Sign In ")
                          ]),
                          _: 1
                        }, 8, ["loading"]),
                        createVNode(unref(Link), {
                          href: _ctx.route("register")
                        }, {
                          default: withCtx(() => [
                            createVNode(_component_v_btn, {
                              rounded: "pill",
                              color: "primary",
                              variant: "outlined",
                              "min-width": "100%"
                            }, {
                              default: withCtx(() => [
                                createTextVNode("Register ")
                              ]),
                              _: 1
                            })
                          ]),
                          _: 1
                        }, 8, ["href"])
                      ]),
                      createVNode(unref(Link), {
                        href: _ctx.route("password.request"),
                        class: "grid place-items-center mt-[20px] text-[10px] not-italic font-normal leading-[7px text-[#5D5FEF]"
                      }, {
                        default: withCtx(() => [
                          createTextVNode(" Forgot your password? ")
                        ]),
                        _: 1
                      }, 8, ["href"])
                    ]),
                    _: 1
                  }, 8, ["onSubmit"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/Login.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
