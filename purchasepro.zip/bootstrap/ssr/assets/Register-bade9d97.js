import { defineComponent, reactive, computed, resolveComponent, unref, withCtx, createTextVNode, createVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { useVuelidate } from "@vuelidate/core";
import { required, email, sameAs } from "@vuelidate/validators";
import { useForm, Head, Link } from "@inertiajs/vue3";
import { L as Layout, C as CustomInput, g as generateErrors } from "./errorGenerator-448112f0.js";
import "@vue/reactivity";
import "@vue/runtime-core";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Register",
  __ssrInlineRender: true,
  setup(__props) {
    const form = useForm({
      name: "",
      email: "",
      password: "",
      password_confirmation: ""
    });
    const $externalResults = reactive({});
    const rules = computed(() => ({
      name: {
        required
      },
      email: {
        required,
        email
      },
      password: {
        required
      },
      password_confirmation: {
        required,
        sameAs: sameAs(form.password)
      }
    }));
    const v$ = useVuelidate(rules, form, { $externalResults });
    const submit = async () => {
      await v$.value.$touch();
      if (v$.value.$invalid) {
        return await false;
      }
      form.post(route("register"), {
        onFinish: () => {
          form.reset("password", "password_confirmation");
        },
        onError: async (err) => {
          await Object.keys(err).forEach((item) => {
            $externalResults[item] = err[item];
          });
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_form = resolveComponent("v-form");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Register" }, null, _parent));
      _push(ssrRenderComponent(Layout, {
        isLoading: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_card_title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Register `);
                } else {
                  return [
                    createTextVNode(" Register ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_card_text, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_v_form, null, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).name,
                          "onUpdate:modelValue": ($event) => unref(form).name = $event,
                          errorMessages: unref(generateErrors)(unref(v$).name),
                          label: "Name",
                          required: "",
                          outlined: "",
                          onInput: ($event) => unref(v$).name.$touch(),
                          onBlur: ($event) => unref(v$).name.$touch(),
                          class: "mt-[20px]"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).email,
                          "onUpdate:modelValue": ($event) => unref(form).email = $event,
                          errorMessages: unref(generateErrors)(unref(v$).email),
                          label: "E-mail",
                          required: "",
                          type: "email",
                          onInput: ($event) => unref(v$).email.$touch(),
                          onBlur: ($event) => unref(v$).email.$touch(),
                          class: "mt-[20px]"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).password,
                          "onUpdate:modelValue": ($event) => unref(form).password = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password),
                          label: "Password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password.$touch(),
                          onBlur: ($event) => unref(v$).password.$touch(),
                          class: "mt-[20px]"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).password_confirmation,
                          "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password_confirmation),
                          label: "Confirm password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password_confirmation.$touch(),
                          onBlur: ($event) => unref(v$).password_confirmation.$touch(),
                          class: "mt-[20px]"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(CustomInput, {
                            modelValue: unref(form).name,
                            "onUpdate:modelValue": ($event) => unref(form).name = $event,
                            errorMessages: unref(generateErrors)(unref(v$).name),
                            label: "Name",
                            required: "",
                            outlined: "",
                            onInput: ($event) => unref(v$).name.$touch(),
                            onBlur: ($event) => unref(v$).name.$touch(),
                            class: "mt-[20px]"
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                          createVNode(CustomInput, {
                            modelValue: unref(form).email,
                            "onUpdate:modelValue": ($event) => unref(form).email = $event,
                            errorMessages: unref(generateErrors)(unref(v$).email),
                            label: "E-mail",
                            required: "",
                            type: "email",
                            onInput: ($event) => unref(v$).email.$touch(),
                            onBlur: ($event) => unref(v$).email.$touch(),
                            class: "mt-[20px]"
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                          createVNode(CustomInput, {
                            modelValue: unref(form).password,
                            "onUpdate:modelValue": ($event) => unref(form).password = $event,
                            errorMessages: unref(generateErrors)(unref(v$).password),
                            label: "Password",
                            required: "",
                            type: "password",
                            outlined: "",
                            onInput: ($event) => unref(v$).password.$touch(),
                            onBlur: ($event) => unref(v$).password.$touch(),
                            class: "mt-[20px]"
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                          createVNode(CustomInput, {
                            modelValue: unref(form).password_confirmation,
                            "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                            errorMessages: unref(generateErrors)(unref(v$).password_confirmation),
                            label: "Confirm password",
                            required: "",
                            type: "password",
                            outlined: "",
                            onInput: ($event) => unref(v$).password_confirmation.$touch(),
                            onBlur: ($event) => unref(v$).password_confirmation.$touch(),
                            class: "mt-[20px]"
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_v_form, null, {
                      default: withCtx(() => [
                        createVNode(CustomInput, {
                          modelValue: unref(form).name,
                          "onUpdate:modelValue": ($event) => unref(form).name = $event,
                          errorMessages: unref(generateErrors)(unref(v$).name),
                          label: "Name",
                          required: "",
                          outlined: "",
                          onInput: ($event) => unref(v$).name.$touch(),
                          onBlur: ($event) => unref(v$).name.$touch(),
                          class: "mt-[20px]"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                        createVNode(CustomInput, {
                          modelValue: unref(form).email,
                          "onUpdate:modelValue": ($event) => unref(form).email = $event,
                          errorMessages: unref(generateErrors)(unref(v$).email),
                          label: "E-mail",
                          required: "",
                          type: "email",
                          onInput: ($event) => unref(v$).email.$touch(),
                          onBlur: ($event) => unref(v$).email.$touch(),
                          class: "mt-[20px]"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                        createVNode(CustomInput, {
                          modelValue: unref(form).password,
                          "onUpdate:modelValue": ($event) => unref(form).password = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password),
                          label: "Password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password.$touch(),
                          onBlur: ($event) => unref(v$).password.$touch(),
                          class: "mt-[20px]"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                        createVNode(CustomInput, {
                          modelValue: unref(form).password_confirmation,
                          "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password_confirmation),
                          label: "Confirm password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password_confirmation.$touch(),
                          onBlur: ($event) => unref(v$).password_confirmation.$touch(),
                          class: "mt-[20px]"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"])
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_card_actions, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_v_spacer, null, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(unref(Link), {
                    href: _ctx.route("login")
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(_component_v_btn, null, {
                          default: withCtx((_4, _push5, _parent5, _scopeId4) => {
                            if (_push5) {
                              _push5(` Already registered? `);
                            } else {
                              return [
                                createTextVNode(" Already registered? ")
                              ];
                            }
                          }),
                          _: 1
                        }, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(_component_v_btn, null, {
                            default: withCtx(() => [
                              createTextVNode(" Already registered? ")
                            ]),
                            _: 1
                          })
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_v_btn, {
                    onClick: submit,
                    color: "#7D74FF",
                    size: "large",
                    variant: "elevated",
                    rounded: "pill",
                    loading: unref(form).processing
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Register`);
                      } else {
                        return [
                          createTextVNode("Register")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_v_spacer),
                    createVNode(unref(Link), {
                      href: _ctx.route("login")
                    }, {
                      default: withCtx(() => [
                        createVNode(_component_v_btn, null, {
                          default: withCtx(() => [
                            createTextVNode(" Already registered? ")
                          ]),
                          _: 1
                        })
                      ]),
                      _: 1
                    }, 8, ["href"]),
                    createVNode(_component_v_btn, {
                      onClick: submit,
                      color: "#7D74FF",
                      size: "large",
                      variant: "elevated",
                      rounded: "pill",
                      loading: unref(form).processing
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Register")
                      ]),
                      _: 1
                    }, 8, ["loading"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_card_title, null, {
                default: withCtx(() => [
                  createTextVNode(" Register ")
                ]),
                _: 1
              }),
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createVNode(_component_v_form, null, {
                    default: withCtx(() => [
                      createVNode(CustomInput, {
                        modelValue: unref(form).name,
                        "onUpdate:modelValue": ($event) => unref(form).name = $event,
                        errorMessages: unref(generateErrors)(unref(v$).name),
                        label: "Name",
                        required: "",
                        outlined: "",
                        onInput: ($event) => unref(v$).name.$touch(),
                        onBlur: ($event) => unref(v$).name.$touch(),
                        class: "mt-[20px]"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                      createVNode(CustomInput, {
                        modelValue: unref(form).email,
                        "onUpdate:modelValue": ($event) => unref(form).email = $event,
                        errorMessages: unref(generateErrors)(unref(v$).email),
                        label: "E-mail",
                        required: "",
                        type: "email",
                        onInput: ($event) => unref(v$).email.$touch(),
                        onBlur: ($event) => unref(v$).email.$touch(),
                        class: "mt-[20px]"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                      createVNode(CustomInput, {
                        modelValue: unref(form).password,
                        "onUpdate:modelValue": ($event) => unref(form).password = $event,
                        errorMessages: unref(generateErrors)(unref(v$).password),
                        label: "Password",
                        required: "",
                        type: "password",
                        outlined: "",
                        onInput: ($event) => unref(v$).password.$touch(),
                        onBlur: ($event) => unref(v$).password.$touch(),
                        class: "mt-[20px]"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                      createVNode(CustomInput, {
                        modelValue: unref(form).password_confirmation,
                        "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                        errorMessages: unref(generateErrors)(unref(v$).password_confirmation),
                        label: "Confirm password",
                        required: "",
                        type: "password",
                        outlined: "",
                        onInput: ($event) => unref(v$).password_confirmation.$touch(),
                        onBlur: ($event) => unref(v$).password_confirmation.$touch(),
                        class: "mt-[20px]"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"])
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }),
              createVNode(_component_v_card_actions, null, {
                default: withCtx(() => [
                  createVNode(_component_v_spacer),
                  createVNode(unref(Link), {
                    href: _ctx.route("login")
                  }, {
                    default: withCtx(() => [
                      createVNode(_component_v_btn, null, {
                        default: withCtx(() => [
                          createTextVNode(" Already registered? ")
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["href"]),
                  createVNode(_component_v_btn, {
                    onClick: submit,
                    color: "#7D74FF",
                    size: "large",
                    variant: "elevated",
                    rounded: "pill",
                    loading: unref(form).processing
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Register")
                    ]),
                    _: 1
                  }, 8, ["loading"])
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/Register.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
