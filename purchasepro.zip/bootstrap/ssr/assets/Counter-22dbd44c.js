import { resolveComponent, mergeProps, withCtx, unref, createVNode, toDisplayString, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate } from "vue/server-renderer";
import { reactive } from "@vue/reactivity";
import { onBeforeMount, watch } from "@vue/runtime-core";
const Counter_vue_vue_type_style_index_0_lang = "";
const _sfc_main = {
  __name: "Counter",
  __ssrInlineRender: true,
  props: {
    modelValue: {},
    attrs: {
      type: Object,
      default: {}
    },
    errorMessages: {
      default: () => []
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const props = __props;
    const states = reactive({
      count: props.modelValue
    });
    onBeforeMount(() => {
      if (props.modelValue) {
        states.count = props.modelValue;
      } else {
        states.count = 0;
      }
    });
    watch(
      () => states.count,
      (val) => {
        if (val === 0) {
          states.count = 1;
        } else {
          emit("update:modelValue", val);
        }
      }
    );
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_input = resolveComponent("v-input");
      const _component_v_btn = resolveComponent("v-btn");
      _push(ssrRenderComponent(_component_v_input, mergeProps({
        variant: "solo",
        "hide-details": "auto",
        "error-messages": __props.errorMessages,
        class: "custom-counter"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="counter-group"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_v_btn, {
              class: "counter-button -left",
              onClick: ($event) => unref(states).count === 0 ? 0 : unref(states).count--,
              icon: "mdi-minus",
              variant: "flat",
              size: "small"
            }, null, _parent2, _scopeId));
            _push2(`<div class="counter-text"${_scopeId}><span${_scopeId}>${ssrInterpolate(unref(states).count)}</span></div>`);
            _push2(ssrRenderComponent(_component_v_btn, {
              class: "counter-button -right",
              onClick: ($event) => unref(states).count++,
              icon: "mdi-plus",
              variant: "flat",
              size: "small"
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "counter-group" }, [
                createVNode(_component_v_btn, {
                  class: "counter-button -left",
                  onClick: ($event) => unref(states).count === 0 ? 0 : unref(states).count--,
                  icon: "mdi-minus",
                  variant: "flat",
                  size: "small"
                }, null, 8, ["onClick"]),
                createVNode("div", { class: "counter-text" }, [
                  createVNode("span", null, toDisplayString(unref(states).count), 1)
                ]),
                createVNode(_component_v_btn, {
                  class: "counter-button -right",
                  onClick: ($event) => unref(states).count++,
                  icon: "mdi-plus",
                  variant: "flat",
                  size: "small"
                }, null, 8, ["onClick"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Input/Counter.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Counter = _sfc_main;
export {
  Counter as C
};
