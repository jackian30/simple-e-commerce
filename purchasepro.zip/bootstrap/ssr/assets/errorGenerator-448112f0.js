import { onMounted, ref, resolveComponent, mergeProps, useSSRContext, withCtx, unref, createVNode, renderSlot } from "vue";
import { ssrRenderComponent, ssrRenderSlot } from "vue/server-renderer";
import { reactive } from "@vue/reactivity";
import { onUnmounted } from "@vue/runtime-core";
import { _ as _export_sfc } from "./_plugin-vue_export-helper-cc2b3d55.js";
const CustomTextField_vue_vue_type_style_index_0_lang = "";
const _sfc_main$1 = {
  __name: "CustomTextField",
  __ssrInlineRender: true,
  props: {
    label: {},
    value: {},
    modelValue: {},
    placeholder: {},
    disabled: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: "text"
    },
    maxlength: {
      type: Number,
      default: 255
    },
    onlyNumbers: {
      type: Boolean,
      default: false
    },
    isFloat: {
      type: Boolean,
      default: false
    },
    suffix: {
      type: String,
      default: null
    },
    errorMessages: {
      default: () => []
    },
    required: {
      type: Boolean,
      default: false
    },
    variant: {
      type: String,
      default: "solo"
    },
    bgColor: {
      type: String,
      default: "rgba(165, 166, 246, 0.1)"
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { expose: __expose }) {
    const props = __props;
    __expose({ focus: () => input.value.focus() });
    onMounted(() => {
      if (input.value.hasAttribute("autofocus")) {
        input.value.focus();
      }
    });
    const input = ref(null);
    function setMaxLength(evt) {
      if (props.modelValue.length >= props.maxlength) {
        evt.preventDefault();
      }
    }
    function isNumber(evt) {
      if (props.type == "number" || props.onlyNumbers) {
        evt = evt ? evt : window.event;
        var charCode = evt.which ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode !== 46 || charCode !== 45 || charCode !== 43)) {
          evt.preventDefault();
        } else {
          return true;
        }
      }
      if (props.isFloat) {
        evt = evt ? evt : window.event;
        var charCode = evt.which ? evt.which : evt.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57) && (charCode !== 45 || charCode !== 43) && charCode !== 46) {
          evt.preventDefault();
        } else {
          return true;
        }
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_text_field = resolveComponent("v-text-field");
      _push(ssrRenderComponent(_component_v_text_field, mergeProps({
        ref_key: "input",
        ref: input,
        "model-value": __props.modelValue,
        type: __props.type,
        label: __props.label,
        placeholder: __props.placeholder,
        "error-messages": __props.errorMessages,
        suffix: __props.suffix,
        disabled: __props.disabled,
        maxlength: __props.maxlength,
        required: __props.required,
        onInput: ($event) => _ctx.$emit("update:modelValue", $event.target.value),
        variant: __props.variant,
        "bg-color": __props.bgColor,
        onKeypress: ($event) => setMaxLength($event) & isNumber($event),
        onPaste: ($event) => setMaxLength($event) & isNumber($event),
        "hide-details": "auto",
        class: "custom-input"
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Input/CustomTextField.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const CustomInput = _sfc_main$1;
const AuthLayout_vue_vue_type_style_index_0_scoped_70b43759_lang = "";
const _sfc_main = {
  __name: "AuthLayout",
  __ssrInlineRender: true,
  props: {
    isLoading: {
      type: Boolean,
      default: true
    }
  },
  setup(__props) {
    const props = __props;
    const state = reactive({
      loading: props.isLoading
    });
    onUnmounted(() => {
      state.loading = false;
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_app = resolveComponent("v-app");
      const _component_v_overlay = resolveComponent("v-overlay");
      const _component_v_progress_circular = resolveComponent("v-progress-circular");
      const _component_v_container = resolveComponent("v-container");
      const _component_v_card = resolveComponent("v-card");
      _push(ssrRenderComponent(_component_v_app, mergeProps({ class: "auth-main" }, _attrs), {
        default: withCtx((_2, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_overlay, {
              modelValue: unref(state).loading,
              "onUpdate:modelValue": ($event) => unref(state).loading = $event,
              persistent: "",
              "content-class": "grid place-items-center w-full h-full"
            }, {
              default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_v_progress_circular, {
                    indeterminate: "",
                    size: "64"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_v_progress_circular, {
                      indeterminate: "",
                      size: "64"
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_container, { class: "auth-container" }, {
              default: withCtx((_3, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_v_card, {
                    "max-width": "500",
                    class: "auth-card"
                  }, {
                    default: withCtx((_4, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push4, _parent4, _scopeId3);
                      } else {
                        return [
                          renderSlot(_ctx.$slots, "default", {}, void 0, true)
                        ];
                      }
                    }),
                    _: 3
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_v_card, {
                      "max-width": "500",
                      class: "auth-card"
                    }, {
                      default: withCtx(() => [
                        renderSlot(_ctx.$slots, "default", {}, void 0, true)
                      ]),
                      _: 3
                    })
                  ];
                }
              }),
              _: 3
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_overlay, {
                modelValue: unref(state).loading,
                "onUpdate:modelValue": ($event) => unref(state).loading = $event,
                persistent: "",
                "content-class": "grid place-items-center w-full h-full"
              }, {
                default: withCtx(() => [
                  createVNode(_component_v_progress_circular, {
                    indeterminate: "",
                    size: "64"
                  })
                ]),
                _: 1
              }, 8, ["modelValue", "onUpdate:modelValue"]),
              createVNode(_component_v_container, { class: "auth-container" }, {
                default: withCtx(() => [
                  createVNode(_component_v_card, {
                    "max-width": "500",
                    class: "auth-card"
                  }, {
                    default: withCtx(() => [
                      renderSlot(_ctx.$slots, "default", {}, void 0, true)
                    ]),
                    _: 3
                  })
                ]),
                _: 3
              })
            ];
          }
        }),
        _: 3
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Layouts/AuthLayout.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Layout = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-70b43759"]]);
const generateErrors = (model, name = null) => {
  let errors = [];
  if (model) {
    model.$errors.forEach((item) => {
      let message = item.$message.replace("Value", name ? name : model.$path).replace("metadata.", "").replace(/[`~!@#$%^&*()_|+\-?;:'",\{\}\[\]\\\/]/gi, " ").replace(".", "").replace(new RegExp("\\bid\\b"), "") + ".";
      errors.push(_.capitalize(message));
    });
  }
  return errors;
};
export {
  CustomInput as C,
  Layout as L,
  generateErrors as g
};
