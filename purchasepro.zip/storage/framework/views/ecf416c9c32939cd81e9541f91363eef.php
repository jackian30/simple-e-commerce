<!DOCTYPE html>
<html>

<head>
  <style>
    table {
      font-family: arial, sans-serif;
      border-collapse: collapse;
      width: 100%;
    }

    td,
    th {
      border: 1px solid #dddddd;
      text-align: left;
      padding: 8px;
    }

    tr:nth-child(even) {
      background-color: #dddddd;
    }
  </style>
</head>

<body>
  <p><strong>Congratulations <?php echo e($user->name); ?>! Your checkout is Successful!</strong></p>

  <p>Here's your order information:</p>

  <table>
    <tr>
      <th>Product</th>
      <th>Quantity</th>
      <th>Price</th>
    </tr>
    <?php $__currentLoopData = $checkoutProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($product->product->name); ?></td>
      <td><?php echo e($product->quantity); ?></td>
      <td>$<?php echo e($product->price); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>

  <p><strong>Total: $<?php echo e($checkout->total_price); ?></strong></p>

</body>

</html><?php /**PATH /var/www/html/resources/views/email/orderInformation.blade.php ENDPATH**/ ?>