import { defineComponent, reactive, computed, resolveComponent, unref, withCtx, createTextVNode, createVNode, withModifiers, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { useVuelidate } from "@vuelidate/core";
import { required, email, sameAs } from "@vuelidate/validators";
import { useForm, Head } from "@inertiajs/vue3";
import { L as Layout, C as CustomInput, g as generateErrors } from "./errorGenerator-448112f0.js";
import "@vue/reactivity";
import "@vue/runtime-core";
import "./_plugin-vue_export-helper-cc2b3d55.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ResetPassword",
  __ssrInlineRender: true,
  props: {
    email: {},
    token: {}
  },
  setup(__props) {
    const props = __props;
    const form = useForm({
      token: props.token,
      email: props.email,
      password: "",
      password_confirmation: ""
    });
    const $externalResults = reactive({});
    const rules = computed(() => ({
      email: {
        required,
        email
      },
      password: {
        required
      },
      password_confirmation: {
        required,
        sameAs: sameAs(form.password)
      }
    }));
    const v$ = useVuelidate(rules, form, { $externalResults });
    const submit = async () => {
      await v$.value.$touch();
      if (v$.value.$invalid) {
        return await false;
      }
      form.post(route("password.store"), {
        onFinish: () => {
          form.reset("password", "password_confirmation");
        },
        onError: async (err) => {
          await Object.keys(err).forEach((item) => {
            $externalResults[item] = err[item];
          });
        }
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_v_card_title = resolveComponent("v-card-title");
      const _component_v_card_text = resolveComponent("v-card-text");
      const _component_v_form = resolveComponent("v-form");
      const _component_v_card_actions = resolveComponent("v-card-actions");
      const _component_v_spacer = resolveComponent("v-spacer");
      const _component_v_btn = resolveComponent("v-btn");
      _push(`<!--[-->`);
      _push(ssrRenderComponent(unref(Head), { title: "Reset Password" }, null, _parent));
      _push(ssrRenderComponent(Layout, {
        isLoading: unref(form).processing
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_v_card_title, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Reset Password `);
                } else {
                  return [
                    createTextVNode(" Reset Password ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_card_text, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_v_form, { onSubmit: submit }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).email,
                          "onUpdate:modelValue": ($event) => unref(form).email = $event,
                          errorMessages: unref(generateErrors)(unref(v$).email),
                          label: "E-mail",
                          required: "",
                          type: "email",
                          onInput: ($event) => unref(v$).email.$touch(),
                          onBlur: ($event) => unref(v$).email.$touch()
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).password,
                          "onUpdate:modelValue": ($event) => unref(form).password = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password),
                          label: "Password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password.$touch(),
                          onBlur: ($event) => unref(v$).password.$touch(),
                          class: "mt-[20px]"
                        }, null, _parent4, _scopeId3));
                        _push4(ssrRenderComponent(CustomInput, {
                          modelValue: unref(form).password_confirmation,
                          "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password_confirmation),
                          label: "Confirm Password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password_confirmation.$touch(),
                          onBlur: ($event) => unref(v$).password_confirmation.$touch(),
                          class: "mt-[20px]"
                        }, null, _parent4, _scopeId3));
                      } else {
                        return [
                          createVNode(CustomInput, {
                            modelValue: unref(form).email,
                            "onUpdate:modelValue": ($event) => unref(form).email = $event,
                            errorMessages: unref(generateErrors)(unref(v$).email),
                            label: "E-mail",
                            required: "",
                            type: "email",
                            onInput: ($event) => unref(v$).email.$touch(),
                            onBlur: ($event) => unref(v$).email.$touch()
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                          createVNode(CustomInput, {
                            modelValue: unref(form).password,
                            "onUpdate:modelValue": ($event) => unref(form).password = $event,
                            errorMessages: unref(generateErrors)(unref(v$).password),
                            label: "Password",
                            required: "",
                            type: "password",
                            outlined: "",
                            onInput: ($event) => unref(v$).password.$touch(),
                            onBlur: ($event) => unref(v$).password.$touch(),
                            class: "mt-[20px]"
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                          createVNode(CustomInput, {
                            modelValue: unref(form).password_confirmation,
                            "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                            errorMessages: unref(generateErrors)(unref(v$).password_confirmation),
                            label: "Confirm Password",
                            required: "",
                            type: "password",
                            outlined: "",
                            onInput: ($event) => unref(v$).password_confirmation.$touch(),
                            onBlur: ($event) => unref(v$).password_confirmation.$touch(),
                            class: "mt-[20px]"
                          }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"])
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_v_form, {
                      onSubmit: withModifiers(submit, ["prevent"])
                    }, {
                      default: withCtx(() => [
                        createVNode(CustomInput, {
                          modelValue: unref(form).email,
                          "onUpdate:modelValue": ($event) => unref(form).email = $event,
                          errorMessages: unref(generateErrors)(unref(v$).email),
                          label: "E-mail",
                          required: "",
                          type: "email",
                          onInput: ($event) => unref(v$).email.$touch(),
                          onBlur: ($event) => unref(v$).email.$touch()
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                        createVNode(CustomInput, {
                          modelValue: unref(form).password,
                          "onUpdate:modelValue": ($event) => unref(form).password = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password),
                          label: "Password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password.$touch(),
                          onBlur: ($event) => unref(v$).password.$touch(),
                          class: "mt-[20px]"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                        createVNode(CustomInput, {
                          modelValue: unref(form).password_confirmation,
                          "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                          errorMessages: unref(generateErrors)(unref(v$).password_confirmation),
                          label: "Confirm Password",
                          required: "",
                          type: "password",
                          outlined: "",
                          onInput: ($event) => unref(v$).password_confirmation.$touch(),
                          onBlur: ($event) => unref(v$).password_confirmation.$touch(),
                          class: "mt-[20px]"
                        }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"])
                      ]),
                      _: 1
                    }, 8, ["onSubmit"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_v_card_actions, null, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_v_spacer, null, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_v_btn, {
                    color: "primary",
                    onClick: submit,
                    variant: "elevated"
                  }, {
                    default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                      if (_push4) {
                        _push4(`Reeset Password`);
                      } else {
                        return [
                          createTextVNode("Reeset Password")
                        ];
                      }
                    }),
                    _: 1
                  }, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_v_spacer),
                    createVNode(_component_v_btn, {
                      color: "primary",
                      onClick: submit,
                      variant: "elevated"
                    }, {
                      default: withCtx(() => [
                        createTextVNode("Reeset Password")
                      ]),
                      _: 1
                    })
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_v_card_title, null, {
                default: withCtx(() => [
                  createTextVNode(" Reset Password ")
                ]),
                _: 1
              }),
              createVNode(_component_v_card_text, null, {
                default: withCtx(() => [
                  createVNode(_component_v_form, {
                    onSubmit: withModifiers(submit, ["prevent"])
                  }, {
                    default: withCtx(() => [
                      createVNode(CustomInput, {
                        modelValue: unref(form).email,
                        "onUpdate:modelValue": ($event) => unref(form).email = $event,
                        errorMessages: unref(generateErrors)(unref(v$).email),
                        label: "E-mail",
                        required: "",
                        type: "email",
                        onInput: ($event) => unref(v$).email.$touch(),
                        onBlur: ($event) => unref(v$).email.$touch()
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                      createVNode(CustomInput, {
                        modelValue: unref(form).password,
                        "onUpdate:modelValue": ($event) => unref(form).password = $event,
                        errorMessages: unref(generateErrors)(unref(v$).password),
                        label: "Password",
                        required: "",
                        type: "password",
                        outlined: "",
                        onInput: ($event) => unref(v$).password.$touch(),
                        onBlur: ($event) => unref(v$).password.$touch(),
                        class: "mt-[20px]"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"]),
                      createVNode(CustomInput, {
                        modelValue: unref(form).password_confirmation,
                        "onUpdate:modelValue": ($event) => unref(form).password_confirmation = $event,
                        errorMessages: unref(generateErrors)(unref(v$).password_confirmation),
                        label: "Confirm Password",
                        required: "",
                        type: "password",
                        outlined: "",
                        onInput: ($event) => unref(v$).password_confirmation.$touch(),
                        onBlur: ($event) => unref(v$).password_confirmation.$touch(),
                        class: "mt-[20px]"
                      }, null, 8, ["modelValue", "onUpdate:modelValue", "errorMessages", "onInput", "onBlur"])
                    ]),
                    _: 1
                  }, 8, ["onSubmit"])
                ]),
                _: 1
              }),
              createVNode(_component_v_card_actions, null, {
                default: withCtx(() => [
                  createVNode(_component_v_spacer),
                  createVNode(_component_v_btn, {
                    color: "primary",
                    onClick: submit,
                    variant: "elevated"
                  }, {
                    default: withCtx(() => [
                      createTextVNode("Reeset Password")
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Auth/ResetPassword.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as default
};
